/** Automatically generated file. DO NOT MODIFY */
package com.androidhive.pushnotifications;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}