Change Log
==========


Version 1.3.0 *(In Development)*
--------------------------------

 * ...


Version 1.2.1 *(2013-02-16)*
--------------------------------

 * Fix: Library not support Android 2.1 and below


Version 1.2.0 *(2013-01-23)*
--------------------------------

 * Support open the menu on the right.


Version 1.1.0 *(2013-01-07)*
----------------------------

 * Support menu items without icons
 * Formatting of the source code
 * Bugfix


Version 1.0.0 *(2012-11-16)*
--------------------------

Initial release.
