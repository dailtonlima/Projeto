/** Automatically generated file. DO NOT MODIFY */
package com.mukesh.cropimage;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}