Content Controls
================

This sample demonstrates Android's content controls.

Browsers: WebView, WebView Browser, Local Content, Generated Content, Javascript Interop

Maps**: Basic MapView, MapView with Annotation, MapView with Overlay

Search: AutoCompleteTextView

Nav: Activity Fade, Activity Zoom, Light Theme


** NOTE: the Map examples require the PrivateStrings.xml "GoogleMapAPIKey" key to be uncommented and a valid key added. See
http://docs.xamarin.com/android/advanced_topics/Obtaining_a_Google_Maps_API_Key (you should also have installed the Google APIs Add-on
via the Android SDK Manager).



Authors
-------

Craig Dunn