MultiTasking
========

Simple example of using a background thread to perform a long running task.

Includes two examples: updating the UI thread on completion 	and starting tasks that run without a notification at the end.


Authors
-------

Bryan Costanich, 
Craig Dunn