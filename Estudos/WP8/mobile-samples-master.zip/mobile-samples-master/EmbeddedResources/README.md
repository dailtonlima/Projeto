Embedded Resource
=========

This sample illustrates how to load a resource that has been built into the assembly by setting 
its build type to EmbeddedResource. It uses a utility class called ResourceLoader that attempts
to locate the resource by name within a given assembly and then load it as a string, byte array
or a stream. In the case of this app, it loads an incredible haiku as a string and then displays
it.


Authors
-------

Bryan Costanich, Rasmus Kromann-Larsen
