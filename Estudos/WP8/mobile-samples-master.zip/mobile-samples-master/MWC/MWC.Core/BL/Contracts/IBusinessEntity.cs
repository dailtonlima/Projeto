using System;

namespace MWC.BL.Contracts
{
	public interface IBusinessEntity
	{
		int ID { get; set; }
	}
}

