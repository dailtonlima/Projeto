// WARNING
//
// This file has been generated automatically by MonoDevelop to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;

namespace MWC.iOS.Screens.iPhone.Home
{
	[Register ("HomeScreen")]
	partial class HomeScreen
	{
		[Outlet]
		MonoTouch.UIKit.UIImageView MwcLogoImageView { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView XamLogoImageView { get; set; }

		[Outlet]
		MonoTouch.UIKit.UITableView SessionTable { get; set; }

		[Outlet]
		MonoTouch.UIKit.UITableView UpNextTable { get; set; }

		[Outlet]
		MonoTouch.UIKit.UITableView FavoritesTable { get; set; }
	}
}
