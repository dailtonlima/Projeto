TODO
====

General
-------
 * 

Scanner Screen
--------------
 * Add more data output
 * create custom cell with various fields
 
Device Details Screen
---------------------
 * Create
 
Bugs
----
