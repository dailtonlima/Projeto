Bluetooth LE Explorer
=====================

Bluetooth LE Explorer is a cross-platform app that lets you scan for nearby 
Bluetooth Low Energy devices, connect to them, enumerate their services, and 
then enumerate those service characteristics.


Authors
-------

Bryan Costanich
