﻿using System.Windows.Controls;

namespace CSWP8LongListSelectorHighlight
{
    public partial class CustomUserControl : UserControl
    {
        public CustomUserControl()
        {
            InitializeComponent();
        }
    }
}
