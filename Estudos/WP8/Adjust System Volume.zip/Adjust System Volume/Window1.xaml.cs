﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;
using CoreAudioApi;
using System.Windows.Threading;
using System.Threading;

namespace Adjust_System_Volume
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private delegate void UpdateSliderDelegate(object obj);
        private readonly MMDevice m_device;
        private bool m_bUpdate = true;

        public Window1()
        {
            InitializeComponent();
            MMDeviceEnumerator devEnum = new MMDeviceEnumerator();
            m_device = devEnum.GetDefaultAudioEndpoint(EDataFlow.eRender, ERole.eMultimedia);
            sldVolume.Value = (int)(m_device.AudioEndpointVolume.MasterVolumeLevelScalar * 100);
            m_device.AudioEndpointVolume.OnVolumeNotification += new AudioEndpointVolumeNotificationDelegate(AudioEndpointVolume_OnVolumeNotification);
            if (m_device.AudioEndpointVolume.Mute)
            {
                lblVolume.Content = "Off";
                lblVolumeImage.ImageSource = new BitmapImage(new Uri("QsMySubY.ico", UriKind.Relative));
            }
            else 
            {
                lblVolume.Content = "On";
                lblVolumeImage.ImageSource = new BitmapImage(new Uri("QsMySubX.ico", UriKind.Relative));
            }

            
        }    

        void AudioEndpointVolume_OnVolumeNotification(AudioVolumeNotificationData data)
        {
            try
            {                
                if (sldVolume.Dispatcher.CheckAccess() )
                {                   
                    sldVolume.Value = (int)data.MasterVolume * 100;                 
                }
                else
                {   
                    sldVolume.Dispatcher.BeginInvoke(new AudioEndpointVolumeNotificationDelegate(AudioEndpointVolume_OnVolumeNotification), DispatcherPriority.Normal, data);
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void sldVolume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {            
            m_device.AudioEndpointVolume.MasterVolumeLevelScalar = ((float)sldVolume.Value / 100.0f);           
        }

        private void lblVolume_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            try
            {
                // TODO: Add event handler implementation here.
                if (lblVolume.Content.ToString() == "On")
                {
                    lblVolume.Content = "Off";
                    lblVolumeImage.ImageSource = new BitmapImage(new Uri("QsMySubY.ico", UriKind.Relative));
                    m_device.AudioEndpointVolume.MasterVolumeLevelScalar = 0;
                }
                else
                {
                    lblVolume.Content = "On";
                    lblVolumeImage.ImageSource = new BitmapImage(new Uri("QsMySubX.ico", UriKind.Relative));
                    m_device.AudioEndpointVolume.MasterVolumeLevelScalar = 0.5F;
                    m_device.AudioEndpointVolume.Mute = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
